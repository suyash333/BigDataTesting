
public class JavaTryCatch {
	public static void main ( String args[])
	{
		System.out.println("This is simple try catch program");
		
		System.out.println(add(1,2));
		
	}
	
	
	
	public static int add( int a, int b) {
		
		int c = a+b;
		return c;
	}
}
